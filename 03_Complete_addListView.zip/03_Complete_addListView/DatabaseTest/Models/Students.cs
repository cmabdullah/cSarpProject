﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DatabaseTest.Models
{
    public class Students
    {
        public Int32 Id { get; set; }
        public string Name { get; set; }
        public string Program { get; set; }
    }

    public class StudentList
    {
        public List<Students> StudentAll { get; set; }
    }
}
