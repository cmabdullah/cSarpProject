﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DatabaseTest.Data;
using DatabaseTest.Models;

namespace DatabaseTest.Controllers
{
    public class HomeController : Controller
    {
        //[RIAZa]
        private readonly TestContext _context;

        public HomeController(TestContext context)
        {
            _context = context;
        }
        //[~RIAZa]
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult StudentsList()
        {
            
            //for single row
            //var test = _context.Students.FirstOrDefault();


            //Students model = new Students
            //{
            //    Id = test.Id,
            //    Name = test.Name

            //};


            //for multiple rows
            var test = _context.Students.ToList();
            StudentList studentModel = new StudentList
            {

                StudentAll = test
            };

            return View(studentModel);
           
        }

        public IActionResult AddStudent()
        {
           

            return View();
        }

        [HttpPost]
        public IActionResult SaveStudent([Bind("Id,Name, Program")]Students students)
        {
            using (var db = _context)
            {

                var std = new Students
                {
                    Id = students.Id,
                    Name = students.Name,
                    Program = students.Program
                };

                db.Students.Add(std);
                db.SaveChanges();
            }

            return RedirectToAction("StudentsList");
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
