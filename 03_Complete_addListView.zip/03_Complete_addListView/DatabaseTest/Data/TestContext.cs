﻿
using Microsoft.EntityFrameworkCore;

namespace DatabaseTest.Data
{
    public class TestContext:DbContext
    {
        public TestContext(DbContextOptions<TestContext> options)
            : base(options)
        {
        }

        public DbSet<DatabaseTest.Models.Students> Students { get; set; }
    }
}
